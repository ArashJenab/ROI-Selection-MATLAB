clear; close all; format compact; clc;


fileName    = 'sample_2.mat';
load(fileName);

cont        = 1;
mNum        = 0;
mainDir     = [cd '\Exported_ROI [' datestr(date,'yyyy-mm-dd') ']/'];
mkdir(mainDir);


while cont==1;
    if mNum~=0;
        % Continuation Option
        ifCont = questdlg({['So far ' num2str(mNum) ' regions were measured for: '];...
        ['"' fileName '"'];...
        ['Continue measuring for another region?']}, ...
        'Continuation Dialog', ...
        'Yes','No','Yes');
    else 
        ifCont 		= 'Yes';
    end

    switch ifCont
        case 'Yes'
            close all;	
            mNum    = mNum+1;
            

            f1=figure(1);
            set(f1,'units','normalized','position',[0.05,0.05,0.9,0.9],'NumberTitle','off','MenuBar', 'None');
            hold all;box on; grid on; 
            plot(x,y);axis tight;
            ylabel('Measured Data');
            title('Select two points around a ROI', 'interpreter','none');			




            %% Two points to be selected
            [px_1, py_1, ~] = ginput (1);
            % Plot the vertical line at the x
            line([px_1 px_1], [min(y) max(y)], 'linestyle', '-', 'color', 'r');
            % Show selected point on curve
            [~, h1]         = min(abs(px_1*ones(length(x),1)-x));
            line(xlim, [y(h1) y(h1)], 'linestyle', '-', 'color', 'g');
            plot(x(h1),y(h1),'ok');
            % Plot the vertical line at the x
            [px_2, py_2, buttons] = ginput (1);
            line([px_2 px_2], [min(y) max(y)], 'linestyle', '-', 'color', 'b');
            % Show selected point on curve
            [aux, h2]       = min(abs(px_2*ones(length(x),1)-x));
            line(xlim, [y(h2) y(h2)], 'linestyle', '-', 'color', 'g');
            plot(x(h2),y(h2),'ok');
            hold off;
            pause(1)

            %% Selected data within range:
            X   = x(h1:h2);
            Y   = y(h1:h2);


            f2=figure(2);
            set(f2,'units','normalized','position',[0.05,0.05,0.9,0.9],'NumberTitle','off','MenuBar', 'None');
            hold all; box on; grid on;
            plot(X,Y); axis tight;
            title(['Measured ROI #' num2str(mNum)]);
            print('-dpdf',[mainDir 'ROI_No' num2str(mNum,'%d')]);
            save([mainDir 'ROI_No' num2str(mNum,'%d') '.mat'], 'X','Y')
        case 'No'
            cont    = 0;
            close all;
    end
end

